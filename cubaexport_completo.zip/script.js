function actualizarRastreo() {
  document.getElementById("tracking").innerText = "En tránsito hacia Cuba (última actualización)";
}

function enviarEmail(e) {
  e.preventDefault();
  document.getElementById("msg").innerText = "✅ Tu mensaje ha sido enviado (simulado).";
}