# 🌍 CubaExport

Sitio web oficial de **CubaExport**, empresa dedicada a las importaciones desde **Estados Unidos** y **España** hacia **Cuba**.

## 📦 Contenido del proyecto
- `index.html` → Página principal
- `style.css` → Estilos de la página
- `script.js` → Funcionalidad básica
- `B28EBBEF-BF55-40E0-8B5B-BA9190FBB8AD.jpeg` → Logo de la empresa
- `C607D598-BF59-464D-81E2-1A983C84E145.jpeg` → Imagen de fondo principal
- `B5BD1EC2-5516-4C55-BA2C-FD7C1E7AB1C3.png` → Imagen adicional para diseño

## 🚀 Cómo visualizar la página

### Opción 1: Local (en tu PC)
1. Descarga o clona este repositorio.
2. Abre el archivo `index.html` en tu navegador favorito.
3. ¡Listo! Verás el sitio funcionando.

### Opción 2: Online (GitHub Pages)
1. Ve a la pestaña **Settings** de este repositorio.
2. En el menú lateral, selecciona **Pages**.
3. En **Source**, selecciona la rama `main` y carpeta `/root`.
4. Guarda los cambios.
5. Tu web estará disponible en:
   ```
   https://TUUSUARIO.github.io/cubaexport/
   ```

## 📞 Contacto
- Teléfonos: +53 555-12345 | +34 600-987654
- Formulario en la página web para contacto directo

---
✍️ Proyecto desarrollado como página informativa básica con **HTML, CSS y JavaScript**.
